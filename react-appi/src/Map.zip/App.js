import 'leaflet/dist/leaflet.css'

import './App.css';



import React from 'react';
import { PrintLayer } from './layers/PrintLayer';

export const App = () => {
  return (<PrintLayer />);
}
