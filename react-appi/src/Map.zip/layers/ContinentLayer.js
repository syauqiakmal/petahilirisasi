// import { GeoJSON } from "react-leaflet";

// export const ContinentsPolygonLayer = ({ data }) => {
//     console.log("Data Continents:", data); // Menampilkan data continents ke konsol
//     return (
//         <GeoJSON
//             data={data}
//             style={(feature) => ({
//                 color: "blue",
//                 weight: 2,
//                 fillOpacity: 0.2
//             })}
//             onEachFeature={(feature, layer) => {
//                 layer.bindPopup(`<b>nama: </b>${feature.properties.PROV}`);
//             }}
//         />
//     );
// }
